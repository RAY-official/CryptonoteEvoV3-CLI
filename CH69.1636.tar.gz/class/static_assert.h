#pragma once

#ifndef __cplusplus
#ifdef __clang__

#define static_assert _Static_assert

#endif
#endif
