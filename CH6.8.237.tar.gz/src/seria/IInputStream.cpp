#include "IInputStream.h"
