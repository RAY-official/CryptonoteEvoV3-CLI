#include "InProcessNodeErrors.h"

namespace CryptoNote {
namespace error {

InProcessNodeErrorCategory InProcessNodeErrorCategory::INSTANCE;

} //namespace error
} //namespace CryptoNote
